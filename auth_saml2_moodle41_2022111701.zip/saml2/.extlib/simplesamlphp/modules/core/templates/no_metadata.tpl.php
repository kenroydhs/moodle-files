<?php

echo '<p>'.$this->t('{core:no_metadata:config_problem}').'</p>';

echo '<ul>';
echo '<li>'.$this->t('{core:no_metadata:suggestion_user_link}').'</li>';
echo '<li>'.$this->t('{core:no_metadata:suggestion_developer}').'</li>';
echo '</ul>';
