<?php

/*
 * Configuration for the module portal.
 */

$config = [
    'pagesets' => [
        ['frontpage_welcome', 'frontpage_config', 'frontpage_auth', 'frontpage_federation'],
        ['sanitycheck', 'statistics'],
    ],
];
